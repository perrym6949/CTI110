user_num = int(input())
x = int(input())
user_sum = user_num // x
sum_user = user_sum // x

print(user_num // x, user_sum // x, sum_user // x)













