num_A = int(input())
num_B = int(input())
num_C = int(input())

if (num_A <= num_B) and (num_A <= num_C):
 min = num_A
elif (num_B <= num_A) and (num_B <= num_C):
 min = num_B
else:
 min = num_C

print(min)
