user_text = input()

print(len(user_text.replace(",", "").replace(".", "").replace(" ","").replace("!","")))




