c = int(input())
d = int(input())

if c>d:
 print("Second integer can't be less than the first.", end="")
while c<=d:
 print(c, end=" ")
 c=c+5



print()