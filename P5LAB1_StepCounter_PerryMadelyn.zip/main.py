def steps_to_miles(user_steps):
  miles = user_steps/2000
  return miles
if __name__ == '__main__':
  steps = int(input(""))
  your_value = steps_to_miles(steps)

  print('{:.2f}'.format(your_value))


