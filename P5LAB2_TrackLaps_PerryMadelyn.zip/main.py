def miles_to_laps(user_miles):
    return user_miles/0.25

if __name__ == '__main__':
    num_miles = float(input(""))
    num_lap = miles_to_laps(num_miles)

    print('{:.2f}'.format(num_lap))

